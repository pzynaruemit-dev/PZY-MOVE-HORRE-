package pzy.move.horre.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import pzy.move.horre.animation.HandPose;
import pzy.move.horre.animation.PzyAnimationEngine;
import pzy.move.horre.animation.PzyRigResources;
import pzy.move.horre.config.PzyConfig;
import pzy.move.horre.mixin.client.accessor.BipedEntityModelAccessor;
import pzy.move.horre.mixin.client.accessor.LivingEntityRendererAccessor;
import pzy.move.horre.mixin.client.accessor.PlayerEntityModelAccessor;

/** Draws PZY's first-person sprint body using the active player's skin texture. */
public final class PzyFirstPersonBodyRenderer {
    private PzyFirstPersonBodyRenderer() { }

    public static void renderSprintBody(MatrixStack matrices, VertexConsumerProvider consumers, int light,
                                        AbstractClientPlayerEntity player, float tickDelta) {
        if (!PzyConfig.isEnabled() || !PzyConfig.isBodyOnSprint() || !PzyConfig.isMovementEnabled()
                || player == null || !player.isSprinting() || player.isSpectator()
                || PzyAnimationEngine.movementAmount() < 0.12f) {
            return;
        }

        EntityRenderer<?> entityRenderer = MinecraftClient.getInstance().getEntityRenderDispatcher().getRenderer(player);
        if (!(entityRenderer instanceof PlayerEntityRenderer renderer)) return;
        if (!(((LivingEntityRendererAccessor) renderer).pzy$getModel() instanceof PlayerEntityModel<?> rawModel)) return;

        BipedEntityModelAccessor biped = (BipedEntityModelAccessor) rawModel;
        PlayerEntityModelAccessor playerParts = (PlayerEntityModelAccessor) rawModel;
        ModelPart body = biped.pzy$getBody();
        ModelPart jacket = playerParts.pzy$getJacket();
        ModelPart rightLeg = biped.pzy$getRightLeg();
        ModelPart leftLeg = biped.pzy$getLeftLeg();
        ModelPart rightPants = playerParts.pzy$getRightPants();
        ModelPart leftPants = playerParts.pzy$getLeftPants();

        // Save every changed component and restore even if a render call fails.
        PartState bodyState = PartState.capture(body);
        PartState jacketState = PartState.capture(jacket);
        PartState rightLegState = PartState.capture(rightLeg);
        PartState leftLegState = PartState.capture(leftLeg);
        PartState rightPantsState = PartState.capture(rightPants);
        PartState leftPantsState = PartState.capture(leftPants);

        try {
            HandPose bodyPose = PzyAnimationEngine.sampleBody(tickDelta);
            float phase = PzyAnimationEngine.movementPhase(tickDelta) * 0.78f;
            float amount = PzyAnimationEngine.movementAmount();
            float legSwing = (float) Math.cos(phase) * 0.72f * amount;

            float runPitch = (float) Math.toRadians(PzyRigResources.get().runBodyPitch * amount);
            body.visible = true;
            jacket.visible = true;
            rightLeg.visible = true;
            leftLeg.visible = true;
            rightPants.visible = true;
            leftPants.visible = true;
            body.pitch = runPitch + (float) Math.toRadians(bodyPose.pitch);
            body.yaw = (float) Math.toRadians(bodyPose.yaw);
            body.roll = (float) Math.toRadians(bodyPose.roll);
            jacket.pitch = body.pitch;
            jacket.yaw = body.yaw;
            jacket.roll = body.roll;
            rightLeg.pitch = legSwing;
            leftLeg.pitch = -legSwing;
            rightPants.pitch = rightLeg.pitch;
            leftPants.pitch = leftLeg.pitch;

            Identifier skin = renderer.getTexture(player);
            VertexConsumer vertices = consumers.getBuffer(RenderLayer.getEntityCutoutNoCull(skin));
            PzyRigResources.Rig rig = PzyRigResources.get();
            float scale = rig.bodyScale * PzyConfig.bodyScale();

            matrices.push();
            try {
                matrices.translate(rig.bodyX + bodyPose.x, rig.bodyY + bodyPose.y, rig.bodyZ + bodyPose.z);
                matrices.scale(scale, -scale, scale);
                body.render(matrices, vertices, light, OverlayTexture.DEFAULT_UV);
                jacket.render(matrices, vertices, light, OverlayTexture.DEFAULT_UV);
                rightLeg.render(matrices, vertices, light, OverlayTexture.DEFAULT_UV);
                rightPants.render(matrices, vertices, light, OverlayTexture.DEFAULT_UV);
                leftLeg.render(matrices, vertices, light, OverlayTexture.DEFAULT_UV);
                leftPants.render(matrices, vertices, light, OverlayTexture.DEFAULT_UV);
            } finally {
                matrices.pop();
            }
        } finally {
            bodyState.restore(body);
            jacketState.restore(jacket);
            rightLegState.restore(rightLeg);
            leftLegState.restore(leftLeg);
            rightPantsState.restore(rightPants);
            leftPantsState.restore(leftPants);
        }
    }

    private record PartState(float pitch, float yaw, float roll, float pivotX, float pivotY,
                             float pivotZ, boolean visible) {
        static PartState capture(ModelPart part) {
            return new PartState(part.pitch, part.yaw, part.roll, part.pivotX, part.pivotY,
                    part.pivotZ, part.visible);
        }
        void restore(ModelPart part) {
            part.pitch = pitch;
            part.yaw = yaw;
            part.roll = roll;
            part.pivotX = pivotX;
            part.pivotY = pivotY;
            part.pivotZ = pivotZ;
            part.visible = visible;
        }
    }
}
