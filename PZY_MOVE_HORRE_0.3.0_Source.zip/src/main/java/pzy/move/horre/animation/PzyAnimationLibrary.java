package pzy.move.horre.animation;

import com.google.gson.Gson;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.resource.ResourceManager;
import net.minecraft.resource.ResourceType;
import net.minecraft.util.Identifier;

import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/** Loads PZY-authored animation clips from the mod's resource namespace. */
public final class PzyAnimationLibrary implements SimpleSynchronousResourceReloadListener {
    public static final PzyAnimationLibrary INSTANCE = new PzyAnimationLibrary();
    private static final Identifier LISTENER_ID = Identifier.of("pzy_move_horre", "animation_library");
    private static final Identifier CLIP_FILE = Identifier.of("pzy_move_horre", "animations/first_person.json");
    private static final Gson GSON = new Gson();
    private static volatile Map<String, AnimationClip> clips = Map.of();

    private PzyAnimationLibrary() { }

    public static void register() {
        ResourceManagerHelper.get(ResourceType.CLIENT_RESOURCES).registerReloadListener(INSTANCE);
    }

    @Override
    public Identifier getFabricId() {
        return LISTENER_ID;
    }

    @Override
    public void reload(ResourceManager manager) {
        try {
            var optional = manager.getResource(CLIP_FILE);
            if (optional.isEmpty()) {
                System.err.println("[PZY MOVE HORRE] Animation resource missing: " + CLIP_FILE);
                clips = Map.of();
                return;
            }
            try (InputStreamReader reader = new InputStreamReader(optional.get().getInputStream(), StandardCharsets.UTF_8)) {
                Root root = GSON.fromJson(reader, Root.class);
                Map<String, AnimationClip> loaded = new HashMap<>();
                if (root != null && root.clips != null) {
                    for (Map.Entry<String, ClipData> entry : root.clips.entrySet()) {
                        ClipData data = entry.getValue();
                        if (data == null || data.frames == null || data.frames.size() < 2) continue;
                        AnimationClip.Frame[] frames = data.frames.stream()
                                .map(f -> new AnimationClip.Frame(f.time, f.x, f.y, f.z, f.pitch, f.yaw, f.roll))
                                .toArray(AnimationClip.Frame[]::new);
                        try {
                            loaded.put(entry.getKey(), new AnimationClip(frames, data.loop));
                        } catch (IllegalArgumentException ignored) {
                            System.err.println("[PZY MOVE HORRE] Ignored invalid animation clip: " + entry.getKey());
                        }
                    }
                }
                clips = Map.copyOf(loaded);
                System.out.println("[PZY MOVE HORRE] Loaded " + clips.size() + " PZY animation clips.");
            }
        } catch (Exception exception) {
            clips = Map.of();
            System.err.println("[PZY MOVE HORRE] Animation resource reload failed: " + exception.getMessage());
        }
    }

    public static boolean sample(String name, float time, HandPose output) {
        AnimationClip clip = clips.get(name);
        if (clip == null) return false;
        clip.sample(time, output);
        return true;
    }

    public static int clipCount() { return clips.size(); }

    private static final class Root { Map<String, ClipData> clips; }
    private static final class ClipData { boolean loop; java.util.List<FrameData> frames; }
    private static final class FrameData {
        float time, x, y, z, pitch, yaw, roll;
    }
}
