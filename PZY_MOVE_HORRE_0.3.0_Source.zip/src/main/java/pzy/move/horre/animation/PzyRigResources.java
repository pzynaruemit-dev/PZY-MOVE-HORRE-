package pzy.move.horre.animation;

import com.google.gson.Gson;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.resource.ResourceManager;
import net.minecraft.resource.ResourceType;
import net.minecraft.util.Identifier;

import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

/** Small PZY rig definition loaded from the PZY resource namespace. */
public final class PzyRigResources implements SimpleSynchronousResourceReloadListener {
    public static final PzyRigResources INSTANCE = new PzyRigResources();
    private static final Identifier ID = Identifier.of("pzy_move_horre", "first_person_rig");
    private static final Identifier FILE = Identifier.of("pzy_move_horre", "models/first_person/rig.json");
    private static final Gson GSON = new Gson();
    private static volatile Rig rig = Rig.defaults();

    private PzyRigResources() { }

    public static void register() {
        ResourceManagerHelper.get(ResourceType.CLIENT_RESOURCES).registerReloadListener(INSTANCE);
    }

    @Override public Identifier getFabricId() { return ID; }

    @Override
    public void reload(ResourceManager manager) {
        try {
            var resource = manager.getResource(FILE);
            if (resource.isEmpty()) return;
            try (InputStreamReader reader = new InputStreamReader(resource.get().getInputStream(), StandardCharsets.UTF_8)) {
                Rig loaded = GSON.fromJson(reader, Rig.class);
                if (loaded != null) {
                    loaded.sanitize();
                    rig = loaded;
                }
            }
        } catch (Exception exception) {
            rig = Rig.defaults();
            System.err.println("[PZY MOVE HORRE] Rig resource reload failed: " + exception.getMessage());
        }
    }

    public static Rig get() { return rig; }

    public static final class Rig {
        public float armOffsetX = 0.0f;
        public float armOffsetY = 0.0f;
        public float armOffsetZ = 0.0f;
        public float bodyX = 0.0f;
        public float bodyY = -0.28f;
        public float bodyZ = 0.36f;
        public float bodyScale = 0.0625f;
        public float runBodyPitch = -8.0f;

        static Rig defaults() { return new Rig(); }
        void sanitize() {
            armOffsetX = finite(armOffsetX, 0.0f, -0.2f, 0.2f);
            armOffsetY = finite(armOffsetY, 0.0f, -0.2f, 0.2f);
            armOffsetZ = finite(armOffsetZ, 0.0f, -0.2f, 0.2f);
            bodyX = finite(bodyX, 0.0f, -0.5f, 0.5f);
            bodyY = finite(bodyY, -0.28f, -1.0f, 0.2f);
            bodyZ = finite(bodyZ, 0.36f, 0.0f, 1.0f);
            bodyScale = finite(bodyScale, 0.0625f, 0.02f, 0.09f);
            runBodyPitch = finite(runBodyPitch, -8.0f, -35.0f, 20.0f);
        }
        private static float finite(float value, float fallback, float min, float max) {
            return Float.isFinite(value) ? Math.max(min, Math.min(max, value)) : fallback;
        }
    }
}
