package pzy.move.horre;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import pzy.move.horre.animation.PzyAnimationEngine;
import pzy.move.horre.animation.PzyAnimationLibrary;
import pzy.move.horre.animation.PzyRigResources;
import pzy.move.horre.config.PzyConfig;
import pzy.move.horre.gui.PzyConfigScreen;

public final class PzyMoveHorreClient implements ClientModInitializer {
    private static final String CATEGORY = "key.categories.pzy_move_horre";

    @Override
    public void onInitializeClient() {
        PzyConfig.load();
        PzyAnimationLibrary.register();
        PzyRigResources.register();

        KeyBinding inspect = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.pzy_move_horre.inspect", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_V, CATEGORY));
        KeyBinding settings = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.pzy_move_horre.open_settings", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_H, CATEGORY));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) {
                PzyAnimationEngine.reset();
                return;
            }
            PzyAnimationEngine.tick(client);
            while (inspect.wasPressed()) {
                if (PzyConfig.isEnabled() && PzyConfig.isActionsEnabled()) PzyAnimationEngine.playInspect();
            }
            while (settings.wasPressed()) client.setScreen(new PzyConfigScreen(client.currentScreen));
        });
    }
}
