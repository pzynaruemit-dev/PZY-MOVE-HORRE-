package pzy.move.horre.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.Items;
import net.minecraft.util.Arm;
import pzy.move.horre.animation.HandPose;
import pzy.move.horre.animation.PzyAnimationEngine;
import pzy.move.horre.animation.PzyRigResources;
import pzy.move.horre.config.PzyConfig;
import net.minecraft.util.math.RotationAxis;

/** PZY first-person arm renderer using Minecraft 1.21.1 player skin and sleeve geometry. */
public final class PzyFirstPersonArmRenderer {
    private PzyFirstPersonArmRenderer() { }

    public static boolean shouldRender(AbstractClientPlayerEntity player) {
        if (player == null || !PzyConfig.isEnabled() || player.isSpectator() || player.isSleeping()) return false;
        if (player.getMainHandStack().isOf(Items.FILLED_MAP) || player.getOffHandStack().isOf(Items.FILLED_MAP)) return false;
        if (player.getMainHandStack().isOf(Items.SPYGLASS) || player.getOffHandStack().isOf(Items.SPYGLASS)) return false;
        return !(player.isUsingItem() && player.getActiveItem().isOf(Items.SPYGLASS));
    }

    public static boolean shouldReplaceArm(AbstractClientPlayerEntity player, Arm arm) {
        if (!shouldRender(player)) return false;
        return arm == player.getMainArm() ? PzyConfig.isMainArmEnabled() : PzyConfig.isOffArmEnabled();
    }

    public static void renderBoth(MatrixStack matrices, VertexConsumerProvider consumers, int light,
                                  AbstractClientPlayerEntity player, float tickDelta) {
        if (!shouldRender(player)) return;
        MinecraftClient client = MinecraftClient.getInstance();
        EntityRenderer<?> rawRenderer = client.getEntityRenderDispatcher().getRenderer(player);
        if (!(rawRenderer instanceof PlayerEntityRenderer renderer)) return;

        Arm main = player.getMainArm();
        float mainSwing = player.getHandSwingProgress(tickDelta);
        if (shouldReplaceArm(player, main)) {
            renderArm(matrices, consumers, light, renderer, player, main, tickDelta, mainSwing);
        }
        Arm off = main.getOpposite();
        if (shouldReplaceArm(player, off)) {
            renderArm(matrices, consumers, light, renderer, player, off, tickDelta, 0.0f);
        }
    }

    private static void renderArm(MatrixStack matrices, VertexConsumerProvider consumers, int light,
                                 PlayerEntityRenderer renderer, AbstractClientPlayerEntity player,
                                 Arm arm, float tickDelta, float swingProgress) {
        float side = arm == Arm.RIGHT ? 1.0f : -1.0f;
        float swing = clamp01(swingProgress);
        float sinSwing = (float) Math.sin(swing * Math.PI);
        float sinDoubleSwing = (float) Math.sin(swing * Math.PI * 2.0);
        float xSwing = -0.30f * sinSwing;
        float ySwing = 0.40f * sinDoubleSwing;
        float zSwing = -0.40f * sinSwing;

        HandPose pose = PzyAnimationEngine.sampleArm(player, arm, tickDelta, swingProgress, 1.0f);
        PzyRigResources.Rig rig = PzyRigResources.get();

        matrices.push();
        pose.apply(matrices);
        matrices.translate(rig.armOffsetX, rig.armOffsetY, rig.armOffsetZ);

        // PZY first-person shoulder transform, aligned with the separately rendered vanilla item.
        matrices.translate(
                side * (0.64f + xSwing),
                ySwing - 0.60f,
                zSwing - 0.72f
        );
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * 45.0f));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * sinSwing * 70.0f));
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * (float) Math.sin(swing * swing * Math.PI) * -20.0f));
        matrices.translate(-side * 3.6f, 3.5f, 0.0f);
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * 120.0f));
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(200.0f));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * -135.0f));
        matrices.translate(side * 5.6f, 0.0f, 0.0f);

        // PlayerEntityRenderer applies the active skin, slim/wide arm geometry, and outer sleeve layer.
        if (arm == Arm.RIGHT) {
            renderer.renderRightArm(matrices, consumers, light, player);
        } else {
            renderer.renderLeftArm(matrices, consumers, light, player);
        }
        matrices.pop();
    }

    public static void applyItemPose(AbstractClientPlayerEntity player, Arm arm, float tickDelta,
                                     float swingProgress, float equipProgress, MatrixStack matrices) {
        if (!shouldReplaceArm(player, arm)) return;
        HandPose pose = PzyAnimationEngine.sampleArm(player, arm, tickDelta, swingProgress, equipProgress);
        pose.apply(matrices);
    }

    private static float clamp01(float value) { return Math.max(0.0f, Math.min(1.0f, value)); }
}
