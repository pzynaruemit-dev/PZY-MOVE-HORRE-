package pzy.move.horre.animation;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import pzy.move.horre.config.PzyConfig;

/**
 * Client-only state machine. State is updated on the client tick; render code
 * only samples immutable clips and interpolates at the supplied tick delta.
 */
public final class PzyAnimationEngine {
    private static final int INSPECT_TICKS = 48;
    private static long ticks;
    private static float movementPhase;
    private static float movementAmount;
    private static float previousMovementAmount;
    private static boolean sprinting, sneaking, swimming, climbing, crawling, falling, fallFlying, jumping;
    private static boolean usingItem;
    private static boolean wasAirborne;
    private static Arm activeUseArm = Arm.RIGHT;
    private static int inspectAge = -1;
    private static int jumpAge = -1;
    private static int landAge = -1;
    private static final ThreadLocal<HandPose> SCRATCH = ThreadLocal.withInitial(HandPose::new);
    private static final ThreadLocal<HandPose> OUTPUT = ThreadLocal.withInitial(HandPose::new);
    private static final ThreadLocal<HandPose> BODY_OUTPUT = ThreadLocal.withInitial(HandPose::new);

    private PzyAnimationEngine() { }

    public static void tick(MinecraftClient client) {
        AbstractClientPlayerEntity player = client.player;
        if (player == null) {
            reset();
            return;
        }

        ticks++;
        double vx = player.getVelocity().x;
        double vz = player.getVelocity().z;
        float horizontal = (float) Math.sqrt(vx * vx + vz * vz);
        previousMovementAmount = movementAmount;
        movementAmount = clamp01(horizontal * 4.5f);
        sprinting = player.isSprinting();
        sneaking = player.isSneaking();
        swimming = player.isSwimming();
        climbing = player.isClimbing();
        fallFlying = player.isFallFlying();
        crawling = player.isInSwimmingPose() && !swimming && !fallFlying;
        boolean airborne = !player.isOnGround() && !swimming && !climbing && !crawling && !fallFlying;
        jumping = airborne && player.getVelocity().y > 0.08;
        falling = airborne && player.getVelocity().y < -0.01;

        if (jumping) {
            jumpAge = jumpAge < 0 ? 0 : Math.min(jumpAge + 1, 10);
        } else {
            jumpAge = -1;
        }
        if (wasAirborne && player.isOnGround()) {
            landAge = 0;
        } else if (landAge >= 0) {
            landAge = landAge >= 7 ? -1 : landAge + 1;
        }
        wasAirborne = airborne;

        movementPhase += 0.20f + movementAmount * (sprinting ? 0.58f : 0.38f);
        if (movementPhase > 10000.0f) movementPhase -= 10000.0f;

        usingItem = player.isUsingItem();
        if (usingItem) {
            Hand hand = player.getActiveHand();
            activeUseArm = hand == Hand.MAIN_HAND ? player.getMainArm() : player.getMainArm().getOpposite();
        }

        if (inspectAge >= 0 && ++inspectAge >= INSPECT_TICKS) inspectAge = -1;
    }

    public static void reset() {
        ticks = 0L;
        movementAmount = previousMovementAmount = movementPhase = 0.0f;
        sprinting = sneaking = swimming = climbing = crawling = falling = fallFlying = jumping = usingItem = false;
        wasAirborne = false;
        activeUseArm = Arm.RIGHT;
        inspectAge = -1;
        jumpAge = -1;
        landAge = -1;
    }

    public static void playInspect() {
        inspectAge = 0;
    }

    public static boolean isInspecting() {
        return inspectAge >= 0;
    }

    public static float movementAmount() { return movementAmount; }
    public static float movementPhase(float tickDelta) { return movementPhase + tickDelta * 0.25f; }

    public static HandPose sampleArm(AbstractClientPlayerEntity player, Arm arm,
                                     float tickDelta, float swingProgress, float equipProgress) {
        HandPose output = OUTPUT.get().clear();
        if (!PzyConfig.isEnabled()) return output;

        float side = arm == Arm.RIGHT ? 1.0f : -1.0f;
        float time = ticks + clamp01(tickDelta);
        float intensity = PzyConfig.intensity();
        float smoothMovement = previousMovementAmount + (movementAmount - previousMovementAmount) * clamp01(tickDelta);

        if (PzyConfig.isIdleEnabled()) {
            sample("idle", time / 80.0f, output, 1.0f, side);
        }

        if (PzyConfig.isMovementEnabled()) {
            if (jumping) {
                sample("jump", clamp01((jumpAge + clamp01(tickDelta)) / 10.0f), output, 0.95f, side);
            } else if (fallFlying) {
                sample("elytra", (time % 30.0f) / 30.0f, output, 1.0f, side);
            } else if (falling) {
                sample("fall", (time % 30.0f) / 30.0f, output, 0.55f, side);
            } else if (landAge >= 0) {
                sample("land", clamp01((landAge + clamp01(tickDelta)) / 7.0f), output, 0.9f, side);
            } else {
                String clip = null;
                float weight = smoothMovement;
                if (swimming) {
                    clip = "swim";
                    weight = Math.max(weight, 0.55f);
                } else if (climbing) {
                    clip = "climb";
                    weight = Math.max(weight, 0.50f);
                } else if (crawling) {
                    clip = "crawl";
                    weight = Math.max(weight, 0.45f);
                } else if (sneaking) {
                    clip = "sneak";
                    weight = Math.max(weight * 0.60f, 0.28f);
                } else if (smoothMovement > 0.015f) {
                    clip = sprinting ? "sprint" : "walk";
                }
                if (clip != null) {
                    float phase = movementPhase(tickDelta) / (sprinting ? 8.0f : 10.0f);
                    if (!sample(clip, phase, output, weight, side)) {
                        float wave = (float) Math.sin(phase * Math.PI * 2.0f);
                        output.x += side * wave * 0.008f * weight;
                        output.pitch += wave * (sprinting ? 4.0f : 2.0f) * weight;
                        output.roll += side * (float) Math.cos(phase * Math.PI * 2.0f) * 1.8f * weight;
                        if (sprinting) output.z -= 0.003f * weight;
                    }
                }
            }
        }

        if (PzyConfig.isActionsEnabled()) {
            if (usingItem && activeUseArm == arm) {
                sample(activeUseClip(player.getActiveItem()), (time % 36.0f) / 36.0f, output, 1.0f, side);
            }
            if (swingProgress > 0.001f) {
                ItemStack heldByThisArm = arm == player.getMainArm()
                        ? player.getMainHandStack() : player.getOffHandStack();
                sample(isTool(heldByThisArm) ? "mine" : "attack", swingProgress, output, 1.0f, side);
            }
            float equipWeight = clamp01(1.0f - equipProgress);
            if (equipWeight > 0.001f) sample("equip", 1.0f - equipWeight, output, equipWeight, side);
            if (inspectAge >= 0) {
                float inspectProgress = clamp01((inspectAge + clamp01(tickDelta)) / (float) INSPECT_TICKS);
                sample("inspect", inspectProgress, output, 1.0f, side);
            }
        }

        // Lite Mode reduces only the final pose amplitude; state and keyframes stay unchanged.
        float finalIntensity = intensity;
        output.x *= finalIntensity;
        output.y *= finalIntensity;
        output.z *= finalIntensity;
        output.pitch *= finalIntensity;
        output.yaw *= finalIntensity;
        output.roll *= finalIntensity;
        return output;
    }

    public static HandPose sampleBody(float tickDelta) {
        HandPose pose = BODY_OUTPUT.get().clear();
        if (!sprinting || !PzyConfig.isBodyOnSprint() || !PzyConfig.isMovementEnabled()) return pose;
        float phase = movementPhase(tickDelta) / 8.0f;
        sample("sprint_body", phase, pose, movementAmount, 1.0f);
        if (pose.isNeutral()) {
            pose.pitch = -4.5f * movementAmount;
            pose.y = (float) Math.sin(phase * Math.PI * 2.0f) * 0.015f * movementAmount;
        }
        float intensity = PzyConfig.intensity();
        pose.x *= intensity; pose.y *= intensity; pose.z *= intensity;
        pose.pitch *= intensity; pose.yaw *= intensity; pose.roll *= intensity;
        return pose;
    }

    private static boolean sample(String name, float time, HandPose output, float weight, float side) {
        if (weight <= 0.0001f) return false;
        HandPose scratch = SCRATCH.get().clear();
        if (!PzyAnimationLibrary.sample(name, time, scratch)) return false;
        scratch.mirror(side);
        output.add(scratch, weight);
        return true;
    }

    private static String activeUseClip(ItemStack stack) {
        if (stack.isOf(Items.POTION) || stack.isOf(Items.MILK_BUCKET) || stack.isOf(Items.HONEY_BOTTLE)) return "use_drink";
        if (stack.contains(DataComponentTypes.FOOD)) return "use_food";
        if (stack.isOf(Items.BOW)) return "use_bow";
        if (stack.isOf(Items.CROSSBOW)) return "use_crossbow";
        if (stack.isOf(Items.SHIELD)) return "use_shield";
        if (stack.isOf(Items.TRIDENT)) return "use_trident";
        if (stack.isOf(Items.FISHING_ROD)) return "use_fishing";
        if (stack.isOf(Items.BRUSH)) return "use_brush";
        if (stack.isOf(Items.SPYGLASS)) return "use_spyglass";
        return "use_item";
    }

    private static boolean isTool(ItemStack stack) {
        return stack.isOf(Items.WOODEN_PICKAXE) || stack.isOf(Items.STONE_PICKAXE)
                || stack.isOf(Items.IRON_PICKAXE) || stack.isOf(Items.GOLDEN_PICKAXE)
                || stack.isOf(Items.DIAMOND_PICKAXE) || stack.isOf(Items.NETHERITE_PICKAXE)
                || stack.isOf(Items.WOODEN_AXE) || stack.isOf(Items.STONE_AXE)
                || stack.isOf(Items.IRON_AXE) || stack.isOf(Items.GOLDEN_AXE)
                || stack.isOf(Items.DIAMOND_AXE) || stack.isOf(Items.NETHERITE_AXE)
                || stack.isOf(Items.WOODEN_SHOVEL) || stack.isOf(Items.STONE_SHOVEL)
                || stack.isOf(Items.IRON_SHOVEL) || stack.isOf(Items.GOLDEN_SHOVEL)
                || stack.isOf(Items.DIAMOND_SHOVEL) || stack.isOf(Items.NETHERITE_SHOVEL)
                || stack.isOf(Items.WOODEN_HOE) || stack.isOf(Items.STONE_HOE)
                || stack.isOf(Items.IRON_HOE) || stack.isOf(Items.GOLDEN_HOE)
                || stack.isOf(Items.DIAMOND_HOE) || stack.isOf(Items.NETHERITE_HOE);
    }

    private static float clamp01(float value) { return Math.max(0.0f, Math.min(1.0f, value)); }
}
