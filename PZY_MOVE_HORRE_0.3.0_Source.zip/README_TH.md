# PZY MOVE HORRE 0.3.0

ม็อดแอนิเมชันมุมมองบุคคลที่หนึ่งสำหรับ **Minecraft Java 1.21.1 + Fabric + Java 21**

## ตัวตนของโปรเจกต์

- ชื่อ: `PZY MOVE HORRE`
- Mod ID: `pzy_move_horre`
- Java Package: `pzy.move.horre`
- ผู้พัฒนา: PZY
- ทำงานฝั่ง Client เท่านั้น
- โค้ด Java และ Resource ที่สร้างเฉพาะโปรเจกต์นี้ใช้ประกาศสิทธิ์ PZY ใน `PZY_LICENSE.txt`

## ระบบที่มีใน Source รุ่นนี้

- PZY First Person Renderer วาดแขนซ้ายและขวาโดยใช้ Skin ของผู้เล่น, geometry แขน Slim/Wide และ sleeve layer ของ Minecraft 1.21.1
- วาดแขน PZY แทนแขน Vanilla เพื่อไม่ให้แขนซ้อนกัน และคงการเรนเดอร์ไอเท็มของ Minecraft
- แสดง torso, jacket, legs และ pants ในมุมมองบุคคลที่หนึ่งขณะ Sprint
- Animation Engine ใช้ Keyframe JSON และ Smoothstep Interpolation
- สถานะ Idle/Breathing, Walk, Sprint, Sneak, Swim, Crawl, Climb, Jump, Fall, Land และ Elytra
- Action animation: Attack, Mining, Equip, Inspect และ Use Item profile สำหรับ Food/Drink, Bow, Crossbow, Shield, Trident, Fishing Rod, Brush และ Spyglass
- PZY Animation และ Rig JSON อยู่ใน Resource Namespace ของม็อด และสามารถ override ผ่าน Resource Pack ที่ใช้ namespace `pzy_move_horre`
- หน้า Settings ธีม Horror ผ่าน Mod Menu เมื่อมี Mod Menu ติดตั้ง และมีปุ่ม `H` เป็นทางเลือก
- ปุ่ม `V` เล่นท่าตรวจสอบอาวุธ
- Config บันทึกที่ `config/pzy_move_horre.json`
- ไม่มี Entity, AI, network packet หรือ particle loop เพิ่ม

## ปุ่มเริ่มต้น

| ปุ่ม | การทำงาน |
|---|---|
| `V` | เล่นท่าตรวจสอบอาวุธ |
| `H` | เปิดการตั้งค่า PZY |

สามารถเปลี่ยนปุ่มได้ที่ Controls > Key Binds

## Build ด้วย Gradle

ต้องใช้ JDK 21 และ Gradle 8.14.3

```bash
gradle --no-daemon clean build
```

ไฟล์ JAR จะอยู่ใน `build/libs/pzy_move_horre-0.3.0.jar`

สำหรับการ Build บนมือถือ ใช้ไฟล์ Source ZIP และ `build.yml` ตามคู่มือ `UPLOAD_GUIDE_TH.md` โดย GitHub Actions จะสร้าง Artifact สำหรับติดตั้งเพียงหนึ่งไฟล์

## ขอบเขตที่ยังไม่ควรเรียกว่า Feature Parity สมบูรณ์

รุ่นนี้เป็นฐาน Renderer/Animation ของ PZY ที่มีแขนจาก Skin และส่วนลำตัวขณะวิ่ง แต่ยังไม่ครอบคลุมทุกระบบของม็อดแอนิเมชันมุมมองบุคคลที่หนึ่งขั้นสูง รายการที่ต้องพัฒนาต่อ ได้แก่:

- First-person armor overlays สำหรับ chestplate, leggings และชั้นเกราะแขน/ลำตัว
- Grip profile และ transform แยกตามชนิดไอเท็มและมือ
- Mining start/loop/end และ attack/critical/sweep variants
- Boat/rowing และท่าขณะขี่พาหนะ
- Compatibility adapters สำหรับม็อดเรนเดอร์อื่น
- การปรับตำแหน่งแขน/ลำตัวจากผลทดสอบในเกมจริงและ Launcher ที่ใช้งาน

อย่าถือว่า Build ผ่านเพียงอย่างเดียวคือทดสอบในเกมผ่าน ต้องทดสอบการแสดงผลใน Minecraft 1.21.1 จริงด้วย

## Resource Layout

```text
assets/pzy_move_horre/
├── animations/first_person.json
├── models/first_person/rig.json
├── lang/
└── icon.png
```

ไฟล์ Resource เหล่านี้ถูกรวมใน JAR ไม่จำเป็นต้องติดตั้ง Resource Pack แยกเพื่อให้แอนิเมชันพื้นฐานทำงาน

## ลิขสิทธิ์

โค้ด Java, Animation JSON, Rig JSON, UI, ภาษา และไอคอนที่สร้างเฉพาะสำหรับ PZY MOVE HORRE อยู่ภายใต้ประกาศ PZY ใน `PZY_LICENSE.txt` ส่วน Minecraft, Fabric, Fabric API, Mod Menu, Java และไลบรารีภายนอกยังคงอยู่ภายใต้ใบอนุญาตของเจ้าของเดิม
