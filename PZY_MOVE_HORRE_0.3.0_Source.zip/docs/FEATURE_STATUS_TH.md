# สถานะคุณสมบัติ PZY MOVE HORRE 0.3.0

## มีอยู่ใน Source รุ่นนี้

- PZY Java/Fabric project, Mod ID และ namespace ของ PZY
- Dedicated first-person arm renderer สำหรับแขนซ้าย/ขวา โดยใช้ PlayerEntityRenderer ของ Minecraft 1.21.1 เพื่ออ่าน Skin ของผู้เล่น, Slim/Wide arm geometry และ sleeve layer
- ยกเลิกการวาดแขน Vanilla ซ้ำ ในขณะที่ยังคงวาดไอเท็ม Vanilla ตามปกติ
- แบ่งสถานะการเคลื่อนไหวและ action ผ่าน Animation Engine
- แสดง torso, jacket, legs และ pants ขณะ Sprint
- โหลด Animation Keyframes และ Rig Settings จาก Resource Namespace ของ PZY
- คลิป JSON: idle, walk, sprint, sneak, swim, crawl, climb, jump, fall, land, elytra, attack, mine, equip, inspect, use_item, use_food, use_drink, use_bow, use_crossbow, use_shield, use_trident, use_fishing, use_brush, use_spyglass และ sprint_body
- Horror Settings Screen ผ่าน Mod Menu และปุ่ม H
- Config แบบ JSON ในโฟลเดอร์ config
- Lite Mode ลด amplitude ของ pose; ตัว Renderer ยังคงเป็น client-side และไม่มี Entity, AI, packet หรือ particle loop เพิ่ม

## ยังไม่ถือว่าเทียบเท่าม็อดอ้างอิงครบทุกระบบ

- First-person armor overlays (chestplate/leggings/armor sleeves)
- Grip และ item transforms ที่แยกตามชนิดอาวุธ/ไอเท็มอย่างละเอียด
- Mining start/loop/end, critical/sweep/weapon combo variants
- Boat/rowing และท่าระหว่างขี่พาหนะ
- Compatibility adapters/blacklist สำหรับม็อดเรนเดอร์อื่น
- การตรวจสอบตำแหน่งและการแสดงผลในเกมจริงกับชุดม็อดและ Launcher ของผู้ใช้

ต้อง Build และทดสอบใน Minecraft 1.21.1 จริงก่อนประกาศว่าเสถียรหรือ Feature Parity สมบูรณ์
