package pzy.move.horre.mixin.client;

import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pzy.move.horre.render.PzyFirstPersonArmRenderer;
import pzy.move.horre.render.PzyFirstPersonBodyRenderer;

/** Replaces only vanilla first-person arm draws with the PZY renderer. */
@Mixin(HeldItemRenderer.class)
public abstract class HeldItemRendererMixin {
    @Inject(method = "renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider$Immediate;Lnet/minecraft/client/network/ClientPlayerEntity;I)V", at = @At("HEAD"))
    private void pzy$renderCustomFirstPersonBodyAndArms(float tickDelta,
                                                        MatrixStack matrices,
                                                        VertexConsumerProvider.Immediate consumers,
                                                        ClientPlayerEntity player,
                                                        int light,
                                                        CallbackInfo ci) {
        if (!PzyFirstPersonArmRenderer.shouldRender(player)) return;
        PzyFirstPersonBodyRenderer.renderSprintBody(matrices, consumers, light, player, tickDelta);
        PzyFirstPersonArmRenderer.renderBoth(matrices, consumers, light, player, tickDelta);
    }

    @Inject(method = "renderArm(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;ILnet/minecraft/util/Arm;)V", at = @At("HEAD"), cancellable = true)
    private void pzy$cancelVanillaArm(MatrixStack matrices, VertexConsumerProvider consumers,
                                      int light, Arm arm, CallbackInfo ci) {
        if (PzyFirstPersonArmRenderer.shouldReplaceArm(net.minecraft.client.MinecraftClient.getInstance().player, arm)) {
            ci.cancel();
        }
    }

    @Inject(method = "renderArmHoldingItem(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;IFFLnet/minecraft/util/Arm;)V", at = @At("HEAD"), cancellable = true)
    private void pzy$cancelVanillaArmHoldingItem(MatrixStack matrices,
                                                 VertexConsumerProvider consumers,
                                                 int light,
                                                 float equipProgress,
                                                 float swingProgress,
                                                 Arm arm,
                                                 CallbackInfo ci) {
        // Keep vanilla item rendering intact; replace only the arm mesh with PZY's skin-based arm.
        if (PzyFirstPersonArmRenderer.shouldReplaceArm(net.minecraft.client.MinecraftClient.getInstance().player, arm)) {
            ci.cancel();
        }
    }

    @Inject(method = "renderFirstPersonItem(Lnet/minecraft/client/network/AbstractClientPlayerEntity;FFLnet/minecraft/util/Hand;FLnet/minecraft/item/ItemStack;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V", at = @At("HEAD"))
    private void pzy$applyMatchingItemPose(AbstractClientPlayerEntity player,
                                           float tickDelta,
                                           float pitch,
                                           Hand hand,
                                           float swingProgress,
                                           ItemStack item,
                                           float equipProgress,
                                           MatrixStack matrices,
                                           VertexConsumerProvider consumers,
                                           int light,
                                           CallbackInfo ci) {
        if (!PzyFirstPersonArmRenderer.shouldRender(player)) return;
        matrices.push();
        Arm arm = hand == Hand.MAIN_HAND ? player.getMainArm() : player.getMainArm().getOpposite();
        PzyFirstPersonArmRenderer.applyItemPose(player, arm, tickDelta, swingProgress, equipProgress, matrices);
    }

    @Inject(method = "renderFirstPersonItem(Lnet/minecraft/client/network/AbstractClientPlayerEntity;FFLnet/minecraft/util/Hand;FLnet/minecraft/item/ItemStack;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V", at = @At("RETURN"))
    private void pzy$restoreMatchingItemPose(AbstractClientPlayerEntity player,
                                             float tickDelta,
                                             float pitch,
                                             Hand hand,
                                             float swingProgress,
                                             ItemStack item,
                                             float equipProgress,
                                             MatrixStack matrices,
                                             VertexConsumerProvider consumers,
                                             int light,
                                             CallbackInfo ci) {
        if (PzyFirstPersonArmRenderer.shouldRender(player)) matrices.pop();
    }
}
