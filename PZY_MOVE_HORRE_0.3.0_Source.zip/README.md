# PZY MOVE HORRE 0.3.0

PZY-authored first-person renderer and animation foundation for Minecraft Java 1.21.1, Fabric, and Java 21.

- Mod ID: `pzy_move_horre`
- Java package: `pzy.move.horre`
- Client-only mod.
- Player-skin first-person arms (slim/wide geometry and sleeve layer), sprint torso/legs, resource-driven keyframe clips, horror settings screen, and Mod Menu integration.
- Default keys: `V` inspect animation, `H` settings.

Build with JDK 21 and Gradle 8.14.3:

```bash
gradle --no-daemon clean build
```

Installable JAR: `build/libs/pzy_move_horre-0.3.0.jar`.

See `README_TH.md` for Thai documentation and `UPLOAD_GUIDE_TH.md` for the mobile GitHub Actions workflow.
