package pzy.move.horre.animation;

import java.util.Arrays;
import java.util.Comparator;

/** Immutable, validated keyframe clip with smoothstep interpolation. */
public final class AnimationClip {
    public record Frame(float time, float x, float y, float z, float pitch, float yaw, float roll) { }

    private final Frame[] frames;
    private final boolean loop;

    public AnimationClip(Frame[] frames, boolean loop) {
        if (frames == null || frames.length < 2) throw new IllegalArgumentException("PZY clips need at least two frames");
        this.frames = frames.clone();
        for (Frame frame : this.frames) {
            if (frame == null || !Float.isFinite(frame.time()) || frame.time() < 0.0f || frame.time() > 1.0f
                    || !Float.isFinite(frame.x()) || !Float.isFinite(frame.y()) || !Float.isFinite(frame.z())
                    || !Float.isFinite(frame.pitch()) || !Float.isFinite(frame.yaw()) || !Float.isFinite(frame.roll())) {
                throw new IllegalArgumentException("PZY keyframes must be finite and normalized");
            }
        }
        Arrays.sort(this.frames, Comparator.comparingDouble(Frame::time));
        float last = -1.0f;
        for (Frame frame : this.frames) {
            if (frame.time() <= last) {
                throw new IllegalArgumentException("PZY keyframes must have unique times");
            }
            last = frame.time();
        }
        this.loop = loop;
    }

    public void sample(float time, HandPose output) {
        float t = Float.isFinite(time) ? time : 0.0f;
        if (loop) t = t - (float) Math.floor(t);
        else t = clamp(t, 0.0f, 1.0f);

        int right = 1;
        while (right < frames.length - 1 && t > frames[right].time()) right++;
        Frame a = frames[right - 1];
        Frame b = frames[right];
        float span = b.time() - a.time();
        float local = span <= 0.0f ? 1.0f : clamp((t - a.time()) / span, 0.0f, 1.0f);
        local = local * local * (3.0f - 2.0f * local);

        output.x = lerp(a.x(), b.x(), local);
        output.y = lerp(a.y(), b.y(), local);
        output.z = lerp(a.z(), b.z(), local);
        output.pitch = lerp(a.pitch(), b.pitch(), local);
        output.yaw = lerp(a.yaw(), b.yaw(), local);
        output.roll = lerp(a.roll(), b.roll(), local);
    }

    private static float lerp(float a, float b, float t) { return a + (b - a) * t; }
    private static float clamp(float v, float min, float max) { return Math.max(min, Math.min(max, v)); }
}
