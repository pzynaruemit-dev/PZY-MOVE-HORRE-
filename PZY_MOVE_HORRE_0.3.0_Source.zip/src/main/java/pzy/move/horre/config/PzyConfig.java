package pzy.move.horre.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** Lightweight local client configuration. It writes only when a setting changes. */
public final class PzyConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("pzy_move_horre.json");
    private static Data data = new Data();

    private PzyConfig() { }

    public static void load() {
        if (!Files.isRegularFile(FILE)) {
            save();
            return;
        }
        try {
            Data loaded = GSON.fromJson(Files.readString(FILE), Data.class);
            data = loaded == null ? new Data() : loaded;
            sanitize();
        } catch (IOException | RuntimeException exception) {
            System.err.println("[PZY MOVE HORRE] Config read failed; using defaults: " + exception.getMessage());
            data = new Data();
        }
    }

    public static void save() {
        sanitize();
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(data));
        } catch (IOException exception) {
            System.err.println("[PZY MOVE HORRE] Config save failed: " + exception.getMessage());
        }
    }

    public static void reset() {
        data = new Data();
        save();
    }

    private static void sanitize() {
        if (data == null) data = new Data();
        if (!Float.isFinite(data.intensity)) data.intensity = 0.85f;
        data.intensity = clamp(data.intensity, 0.25f, 1.35f);
        if (!Float.isFinite(data.bodyScale)) data.bodyScale = 0.85f;
        data.bodyScale = clamp(data.bodyScale, 0.50f, 1.25f);
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    public static Data data() { return data; }
    public static boolean isEnabled() { return data.enabled; }
    public static boolean isMainArmEnabled() { return data.mainArm; }
    public static boolean isOffArmEnabled() { return data.offArm; }
    public static boolean isBodyOnSprint() { return data.bodyOnSprint; }
    public static boolean isIdleEnabled() { return data.idle; }
    public static boolean isMovementEnabled() { return data.movement; }
    public static boolean isActionsEnabled() { return data.actions; }
    public static boolean isLiteMode() { return data.liteMode; }
    public static boolean isHorrorTheme() { return data.horrorTheme; }
    public static float intensity() { return data.intensity * (data.liteMode ? 0.82f : 1.0f); }
    public static float bodyScale() { return data.bodyScale; }

    public static final class Data {
        public boolean enabled = true;
        public boolean mainArm = true;
        public boolean offArm = true;
        public boolean bodyOnSprint = true;
        public boolean idle = true;
        public boolean movement = true;
        public boolean actions = true;
        public boolean liteMode = true;
        public boolean horrorTheme = true;
        public float intensity = 0.85f;
        public float bodyScale = 0.85f;
    }
}
