package pzy.move.horre.animation;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.RotationAxis;

/** Shared transform sampled once for the PZY arm and its held item. */
public final class HandPose {
    public float x, y, z;
    public float pitch, yaw, roll;

    public HandPose clear() {
        x = y = z = pitch = yaw = roll = 0.0f;
        return this;
    }

    public HandPose add(HandPose other, float weight) {
        x += other.x * weight;
        y += other.y * weight;
        z += other.z * weight;
        pitch += other.pitch * weight;
        yaw += other.yaw * weight;
        roll += other.roll * weight;
        return this;
    }

    public HandPose mirror(float side) {
        x *= side;
        yaw *= side;
        roll *= side;
        return this;
    }

    public void apply(MatrixStack matrices) {
        matrices.translate(x, y, z);
        if (pitch != 0.0f) matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(pitch));
        if (yaw != 0.0f) matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(yaw));
        if (roll != 0.0f) matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(roll));
    }

    public boolean isNeutral() {
        return x == 0.0f && y == 0.0f && z == 0.0f
                && pitch == 0.0f && yaw == 0.0f && roll == 0.0f;
    }
}
