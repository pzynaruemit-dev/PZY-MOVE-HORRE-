# วิธี Build PZY MOVE HORRE 0.3.0 ด้วย GitHub จากมือถือ

ไฟล์ที่ต้องอัปโหลดมี 2 ไฟล์เท่านั้น:

1. `PZY_MOVE_HORRE_0.3.0_Source.zip` — อัปโหลดไว้ที่ Root ของ Repository
2. `build.yml` — อัปโหลดไว้ที่ `.github/workflows/build.yml` และแทนที่ Workflow เก่า

จากนั้น Commit changes และเปิดแท็บ Actions

GitHub Actions จะ:

1. ติดตั้ง Java 21 และ Gradle 8.14.3
2. แตก Source ZIP อย่างปลอดภัย
3. Build และ Remap JAR สำหรับ Fabric 1.21.1
4. ตรวจ Metadata, Mixin, Renderer, Animation และ Resource ภายใน JAR
5. ส่งออก Artifact สำหรับติดตั้ง **เพียงหนึ่งไฟล์**

ชื่อ Artifact:

`PZY-MOVE-HORRE-0.3.0-Fabric-1.21.1`

ดาวน์โหลด Artifact แล้วแตก ZIP จากนั้นนำ `pzy_move_horre-0.3.0.jar` ไปใส่โฟลเดอร์ `mods`

ไม่ต้องติดตั้ง Source ZIP และไม่ต้องติดตั้ง `sources.jar` เพราะ Workflow นี้ไม่ได้สร้าง Artifact ซอร์สแยก

หาก Build ล้มเหลว ให้เปิด Actions > Build Fabric 1.21.1 mod > Build and remap PZY mod แล้วส่งภาพหรือข้อความ Error จากขั้นตอนนั้น ไม่ต้องส่งเฉพาะหน้ารวม Actions
