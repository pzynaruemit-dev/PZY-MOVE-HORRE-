package pzy.move.horre.mixin.client.accessor;

import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(BipedEntityModel.class)
public interface BipedEntityModelAccessor {
    @Accessor("body") ModelPart pzy$getBody();
    @Accessor("rightLeg") ModelPart pzy$getRightLeg();
    @Accessor("leftLeg") ModelPart pzy$getLeftLeg();
}
