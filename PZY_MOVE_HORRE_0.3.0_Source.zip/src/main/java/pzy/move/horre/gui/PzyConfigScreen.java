package pzy.move.horre.gui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import pzy.move.horre.config.PzyConfig;

import java.util.function.Consumer;
import java.util.function.Supplier;

/** Compact horror-styled settings panel, suitable for small screens. */
public final class PzyConfigScreen extends Screen {
    private final Screen parent;

    public PzyConfigScreen(Screen parent) {
        super(Text.translatable("screen.pzy_move_horre.title"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int panelWidth = Math.min(420, width - 16);
        int x = (width - panelWidth) / 2;
        int y = Math.max(54, height / 2 - 110);
        int gap = 6;
        int col = (panelWidth - 30 - gap) / 2;
        int left = x + 12;
        int right = left + col + gap;
        int row = 23;

        addToggle(left, y, col, "screen.pzy_move_horre.core", () -> PzyConfig.data().enabled, v -> PzyConfig.data().enabled = v);
        addToggle(right, y, col, "screen.pzy_move_horre.off_arm", () -> PzyConfig.data().offArm, v -> PzyConfig.data().offArm = v);
        addToggle(left, y + row, col, "screen.pzy_move_horre.main_arm", () -> PzyConfig.data().mainArm, v -> PzyConfig.data().mainArm = v);
        addToggle(right, y + row, col, "screen.pzy_move_horre.body", () -> PzyConfig.data().bodyOnSprint, v -> PzyConfig.data().bodyOnSprint = v);
        addToggle(left, y + row * 2, col, "screen.pzy_move_horre.idle", () -> PzyConfig.data().idle, v -> PzyConfig.data().idle = v);
        addToggle(right, y + row * 2, col, "screen.pzy_move_horre.movement", () -> PzyConfig.data().movement, v -> PzyConfig.data().movement = v);
        addToggle(left, y + row * 3, col, "screen.pzy_move_horre.actions", () -> PzyConfig.data().actions, v -> PzyConfig.data().actions = v);
        addToggle(left, y + row * 4, col, "screen.pzy_move_horre.horror_theme", () -> PzyConfig.data().horrorTheme, v -> PzyConfig.data().horrorTheme = v);
        addToggle(right, y + row * 4, col, "screen.pzy_move_horre.lite_mode", () -> PzyConfig.data().liteMode, v -> PzyConfig.data().liteMode = v);

        addDrawableChild(ButtonWidget.builder(intensityText(), button -> {
            float[] values = {0.50f, 0.65f, 0.85f, 1.00f, 1.15f, 1.30f};
            PzyConfig.data().intensity = nextValue(PzyConfig.data().intensity, values);
            button.setMessage(intensityText());
            PzyConfig.save();
        }).dimensions(x + 12, y + row * 5 + 3, panelWidth - 24, 20).build());

        addDrawableChild(ButtonWidget.builder(bodyScaleText(), button -> {
            float[] values = {0.60f, 0.75f, 0.85f, 1.00f, 1.10f, 1.20f};
            PzyConfig.data().bodyScale = nextValue(PzyConfig.data().bodyScale, values);
            button.setMessage(bodyScaleText());
            PzyConfig.save();
        }).dimensions(x + 12, y + row * 5 + 25, panelWidth - 24, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.translatable("screen.pzy_move_horre.reset"), button -> {
            PzyConfig.reset();
            clearChildren();
            init();
        }).dimensions(x + 12, y + row * 5 + 48, col, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.translatable("screen.pzy_move_horre.save_return"), button -> close())
                .dimensions(x + 18 + col, y + row * 5 + 48, col, 20).build());
    }

    private static float nextValue(float current, float[] values) {
        for (int i = 0; i < values.length; i++) {
            if (current < values[i] - 0.001f) return values[i];
        }
        return values[0];
    }

    private void addToggle(int x, int y, int w, String key, Supplier<Boolean> getter, Consumer<Boolean> setter) {
        addDrawableChild(ButtonWidget.builder(toggleText(key, getter.get()), button -> {
            boolean next = !getter.get();
            setter.accept(next);
            button.setMessage(toggleText(key, next));
            PzyConfig.save();
        }).dimensions(x, y, w, 20).build());
    }

    private static Text toggleText(String key, boolean enabled) {
        return Text.translatable("screen.pzy_move_horre.toggle", Text.translatable(key),
                Text.translatable(enabled ? "screen.pzy_move_horre.on" : "screen.pzy_move_horre.off"));
    }

    private static Text intensityText() {
        return Text.translatable("screen.pzy_move_horre.intensity", Math.round(PzyConfig.data().intensity * 100.0f));
    }

    private static Text bodyScaleText() {
        return Text.translatable("screen.pzy_move_horre.body_scale", Math.round(PzyConfig.data().bodyScale * 100.0f));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        boolean horror = PzyConfig.isHorrorTheme();
        int overlay = horror ? 0xD90A070B : 0xD90A1018;
        int panel = horror ? 0xF0160D13 : 0xF0101923;
        int accent = horror ? 0xFF9B263F : 0xFF4C829F;
        int title = horror ? 0xFFF1DDE3 : 0xFFE0ECF4;
        int muted = horror ? 0xFFB08B98 : 0xFF91A8BA;
        context.fill(0, 0, width, height, overlay);
        int panelWidth = Math.min(420, width - 16);
        int x = (width - panelWidth) / 2;
        int top = Math.max(8, height / 2 - 145);
        int bottom = Math.min(height - 8, top + 310);
        context.fill(x, top, x + panelWidth, bottom, panel);
        context.fill(x, top, x + panelWidth, top + 3, accent);
        context.fill(x, top, x + 2, bottom, accent);
        context.drawCenteredTextWithShadow(textRenderer, Text.translatable("screen.pzy_move_horre.title"), width / 2, top + 12, title);
        context.drawCenteredTextWithShadow(textRenderer, Text.translatable("screen.pzy_move_horre.subtitle"), width / 2, top + 27, muted);
        context.fill(x + 18, top + 43, x + panelWidth - 18, top + 44, accent);
        context.drawCenteredTextWithShadow(textRenderer, Text.translatable("screen.pzy_move_horre.footer"), width / 2, bottom - 13, muted);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public void close() {
        PzyConfig.save();
        if (client != null) client.setScreen(parent);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
